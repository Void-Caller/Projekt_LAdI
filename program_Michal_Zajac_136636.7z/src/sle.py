__all__ = [
    'parse',
    'parse_symbolic',
    'get_matrix_and_vector',
    'replace_column',
    'get_det_equation',
    'calculate_determinant',
    'calculate_dets',
    'calculate_equation',
    'get_matrix_and_vector_from_file',
    'get_matrix_and_vector_from_file_symbolic',
    'put_result_to_file',
]

import re
from copy import deepcopy
import math

def parse(equation: str):
    """
    parse equation to form [equation: [factor_x[number], ...], constant_term]

    Args:
        equation (str): [
            string in the form of [2x0 +3x1 = 4;3x0 -1.5x1 = 0.5]
        ]

    Returns:
        [list]: [
            [equation: [factor_x[number], ...], constant_term]
        ]
    """
    equations = equation.split(';')
    equations = [eq.split('=') for eq in equations]
    for eq in equations:
        eq[0] = re.sub('x[0-9]', ' ', eq[0])
        eq[0] = eq[0].split(' ')
        eq[0] = [float(x) for x in eq[0] if x != '']
        eq[1] = float(eq[1])

    return equations

def parse_symbolic(equation: str):
    equations = equation.split(';')
    equations = [eq.split('=') for eq in equations]
    for eq in equations:
        eq[0] = re.sub('x[0-9]', ' ', eq[0])
        eq[0] = eq[0].split(' ')
        eq[0] = [x for x in eq[0] if x != '']

    return equations

def get_matrix_and_vector(equations):
    """
    make matrix and vector from list in the
    form of [equation: [factor_x[number], ...], constant_term]

    Args:
        equations ([list]): [
            list in the form of [equation: [factor_x[number], ...], constant_term]
        ]

    Returns:
        [list[list], list]: [
            return the matrix from the coefficients of the equations
            return the vector from the constant_terms of the equations
        ]
    """
    matrix = [eq[0] for eq in equations]
    vector = [eq[1] for eq in equations]

    return matrix, vector

def replace_column(matrix, column, vector):
    """returns a new matrix with column replaced by vector

    Args:
        matrix ([list[list]]): [matrix do replace]
        column ([int]): [column number to replace]
        vector ([list]): [vector to insert]

    Returns:
        [list[list]]: [matrix with column replaced by vector]
    """
    new_matrix = deepcopy(matrix)
    for i in range(len(new_matrix)):
        new_matrix[i][column] = vector[i]

    return new_matrix

def get_det_equation(matrix):
    """
    return coefficients to calculate in the form of
    [elements_to_add: [elements_to_mult: [...]], elements_to_sub: [elements_to_mult: [...]]]

    Args:
        matrix ([list[list]]): [matrix to convert to form for calculations]

    Returns:
        [list[list], list[list]]: [elements_to_add: [elements_to_mult: [...]], elements_to_sub: [elements_to_mult: [...]]]
    """
    result_plus = [[] for _ in range(len(matrix))]
    result_minus = [[] for _ in range(len(matrix))]

    if len(matrix) == 2:
        return [[[matrix[0][0], matrix[1][1]]], [[matrix[0][1], matrix[1][0]]]]

    for i in range(len(matrix)):
        for j in range(len(matrix)):
            idx = (i + j) % len(matrix)
            result_plus[j].append(matrix[idx][i])

    for i in range(len(matrix) - 1, -1 , -1):
        h = len(matrix) - 1
        for j in range(len(matrix)):
            idx = (i - j) % len(matrix)
            result_minus[idx].append(matrix[h][i])
            h -= 1

    return [result_plus, result_minus]

def calculate_determinant(matrix):
    """
    return value of matrix determinant and
    coefficients needed calculate in form the
    [list[list], list[list]]: [elements_to_add: [elements_to_mult: [...]], elements_to_sub: [elements_to_mult: [...]]]

    Args:
        matrix ([list[list]]): [the matrix to calculate]

    Returns:
        [(number, [list[list], list[list]])]: [
            return: determinant of matrix
            return: coefficients needed calculate
        ]
    """
    det_equation = get_det_equation(matrix)
    p_plus, p_minus = det_equation

    result = sum([math.prod(p) for p in p_plus]) + sum([-math.prod(p) for p in p_minus])

    return result, det_equation

def calculate_dets(matrix, vector):
    """
    return all determinants of equation in matrix/vector form and
    list of coefficients needed calculate

    Args:
        matrix ([list[list]]): [matrix to calculate]
        vector ([list]): [list of constant_term]

    Returns:
        [(number, list[number], list[list of coefficients])]: [
            return main det, list of det with replaced columns by constant_terms and
            list[coefficients needed calculate]
        ]
    """
    det_equations = []
    sub_dets = []

    main_det, det_equation = calculate_determinant(matrix)
    det_equations.append(det_equation)

    for column in range(len(matrix)):
        sub_det = replace_column(matrix, column, vector)
        sub_det, det_equation = calculate_determinant(sub_det)

        det_equations.append(det_equation)
        sub_dets.append(sub_det)

    return main_det, sub_dets, det_equations

def calculate_equation(main_det, sub_dets):
    """
    calculate unkonw coefficients in equation from
    main determinant and sub determinants

    Args:
        main_det ([number]): [value of matrix determinant]
        sub_dets ([list[number]]): [values of matrix sub determinants]

    Returns:
        [dict]: [return dict of {'unknow variable': 'value'}]
    """
    result = {}
    if main_det != 0:
        for idx in range(len(sub_dets)):
            result[f'x{idx}'] = sub_dets[idx]/main_det
        return result

    if main_det == 0 and all([det == 0 for det in sub_dets]):
        return {'result': 'infinitely many solutions'}
    else:
        return {'result': 'has no solutions'}

def get_matrix_and_vector_from_file(file_content):
    """
    return matrix and vector from equation in file

    Args:
        path ([string]): [path to file with equation]

    Returns:
        [(matrix, vector)]: [rturn equation in matrix/vector form]
    """
    equations = parse(file_content)
    matrix, vector = get_matrix_and_vector(equations)

    return matrix, vector

def get_matrix_and_vector_from_file_symbolic(file_content):
    equations = parse_symbolic(file_content)
    matrix, vector = get_matrix_and_vector(equations)

    return matrix, vector

def put_result_to_file(path, result):
    """
    write result of calculations to file

    Args:
        path ([string]): [path to file]
        result ([dict]): [dict with result of calculations]
    """
    with open(path, 'w') as f:
        for r in result:
            f.write(f'{r} = {result[r]}\n')

def get_det_equations_symbolic(matrix, vector):
    """[summary]

    Args:
        matrix ([type]): [description]
        vector ([type]): [description]

    Returns:
        [type]: [description]
    """
    result = []

    result.append(get_det_equation(matrix))

    for column in range(len(vector)):
        new_matrix = replace_column(matrix, column, vector)
        result.append(get_det_equation(new_matrix))

    return result

def calculate_equation_symbolic(det_eqs):
    """[summary]

    Args:
        det_eqs ([type]): [description]

    Returns:
        [type]: [description]
    """
    result = {}
    dets = deepcopy(det_eqs)
    eqs = []
    for det_eq in dets:
        for i in range(len(det_eq)):
            for j in range(len(det_eq[i])):
                det_eq[i][j] = '(' + ' * '.join(det_eq[i][j]) + ')'
            if (i == 0):
                det_eq[i] = ' + '.join(det_eq[i])
            else:
                det_eq[i] = ' - '.join(det_eq[i])
        eqs.append('-'.join(det_eq))

    for i in range(1, len(eqs)):
        result[f'x{i-1}'] = '(' + eqs[i] + ')/(' + eqs[0] + ')'

    return result
