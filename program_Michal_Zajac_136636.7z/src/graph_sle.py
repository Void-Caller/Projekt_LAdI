__all__ = [
    'get_graph_edges',
    'mult_dict_to_one_dict',
    'mult_dict_to_one_dict',
    'full_equation_to_dict',
    'sub_equation_to_dict',
    'get_equation_coeff',
    'get_all_edges',
]


from copy import deepcopy

position = 0

def get_graph_edges(param_coeff, sign_coeff):
    """
    return list of tuples with connections of coefficients

    Args:
        param_coeff ([list]): [list of index of numeric coefficients]
        sign_coeff ([list]): [list of index of sign coefficients]

    Returns:
        [list[tuple]]: [list with tuple of indexes to connection in graph]
    """
    if len(param_coeff) == 2:
        return [(param_coeff[0], sign_coeff[0]), (param_coeff[1], sign_coeff[0])]
    else:
        return [(param_coeff.pop(), sign_coeff[len(param_coeff) - 1]),
        (sign_coeff[len(param_coeff) - 2], sign_coeff[len(param_coeff) - 3])] + get_graph_edges(param_coeff, sign_coeff)

def mult_dict_to_one_dict(dictio):
    """
    convert nested dict to flat dict
    dict in form {
        a: {
            a: ...
            b: ...
        }
    }

    Args:
        dictio ([dict]): [nested dict]

    Returns:
        [dict]: [dict in form {a: ..., b: ...}]
    """
    result = dictio.copy()
    for element in dictio:
        if isinstance(dictio[element], dict):
            result.update(mult_dict_to_one_dict(dictio[element]))

    return result

def equation_to_dict(sign, equation):
    """
    return dict of {index: value}

    Args:
        sign ([str]): [operation]
        equation ([list]): [list of coefficients to arithmetic operation]

    Returns:
        [dict]: [dict in form {
            [index: value]
        }]

    example:
    {
        3: '*',
        4: '*',
        5: '2',
        6: '5',
        7: '7'
    }
    """
    result = {}
    global position

    for x in range(len(equation) - 1):
        result[position] = sign
        position += 1

    for coeff in equation:
        result[position] = coeff
        position += 1

    return result

# [[plus: [mult: ]][minus: [mult: ]]]
def full_equation_to_dict(equation):
    """
    create nested dict of full equation,
    equation form:
    [elements_to_add: [elements_to_mult: [...]], elements_to_sub: [elements_to_mult: [...]]]

    Args:
        equation ([list[list[list]]]): [coefficients needed to calculate equations]

    Returns:
        [dict]: [nested dict with value and indexes]
    """
    global position
    result = {}
    result[position] = '-'
    position += 1

    if len(equation[0]) != 1:
        save_pos = position
        result[save_pos] = equation_to_dict('+', equation[0])
        sub_equation_to_dict(deepcopy(result), save_pos, result)

        save_pos = position
        result[save_pos] = equation_to_dict('-', equation[1])
        sub_equation_to_dict(deepcopy(result), save_pos, result)
    else:
        save_pos = position
        result[save_pos] = equation_to_dict('*', equation[0][0])

        save_pos = position
        result[save_pos] = equation_to_dict('*', equation[1][0])

    return result

def sub_equation_to_dict(sub_equation, start_position, result):
    """
    make dict more consistent by form
    {
        1: {
            1: ...
        }
    }
    """
    global position
    re = deepcopy(sub_equation)
    for idx in re[start_position]:
        if isinstance(result[start_position][idx], list):
            s_pos = position
            result[start_position][s_pos] = equation_to_dict('*', result[start_position].pop(idx))

def get_equation_coeff(dict_equation):
    """
    get all indexes of sub equations of equation in one list of lists

    Args:
        dict_equation ([dict]): [nested dict with indexes and values]

    Returns:
        [list[list]]: [all indexes of sub equations of equation]
    """
    result = []
    for layer in dict_equation:
        if isinstance(dict_equation[layer], dict):
            for sec_layer in dict_equation[layer]:
                if isinstance(dict_equation[layer][sec_layer], dict):
                    result.append(list(dict_equation[layer][sec_layer].keys()))
            result.append(list(dict_equation[layer].keys()))

    result.append(list(dict_equation.keys()))
    return result

def get_all_edges(coeffs):
    """
    get all edges in graph

    Args:
        coeffs ([list[list]]): [all sub equations indexes in list of list]

    Returns:
        [list[tuple]]: [all pairs connected coefficients]
    """
    result = []
    for coeff in coeffs:
        separator = len(coeff) // 2
        revers = coeff[:separator]
        revers.reverse()
        result.extend(get_graph_edges(coeff[separator:], revers))

    return result
