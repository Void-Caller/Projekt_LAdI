import networkx as nx
import matplotlib.pyplot as plt
import re
from src import graph_sle as gsle
from src import sle

class Calculator:
    @staticmethod
    def calculate(input, output):
        file_content = open(input, 'r').read()
        det_eq = None
        result = None

        if (not re.search('[a-wy-zA-WY-Z]', file_content)):
            matrix, vector = sle.get_matrix_and_vector_from_file(file_content)
            main_det, sub_dets, det_eq = sle.calculate_dets(matrix, vector)
            result = sle.calculate_equation(main_det, sub_dets)
        else:
            matrix, vector = sle.get_matrix_and_vector_from_file_symbolic(file_content)
            det_eq = sle.get_det_equations_symbolic(matrix, vector)
            result = sle.calculate_equation_symbolic(det_eq)

        sle.put_result_to_file(output, result)

        for idx in range(len(det_eq)):
            graph = nx.Graph()

            dictio = gsle.full_equation_to_dict(det_eq[idx])
            coeffs = gsle.get_equation_coeff(dictio)
            edges = gsle.get_all_edges(coeffs)
            one_dict = gsle.mult_dict_to_one_dict(dictio)

            nodes = one_dict.keys()
            graph.add_nodes_from(nodes)
            graph.add_edges_from(edges)
            pos = nx.spring_layout(graph)
            nx.draw_networkx_labels(graph, pos, one_dict)
            nx.draw(graph, pos)
            plt.savefig(f'graphs/W_{idx}')
            plt.clf()
