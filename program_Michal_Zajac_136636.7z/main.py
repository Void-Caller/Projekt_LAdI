from Calculator import Calculator

if __name__ == "__main__":
    Calculator.calculate('equation/eq', 'result/result')
