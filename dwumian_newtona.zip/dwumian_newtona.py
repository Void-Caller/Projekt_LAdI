import cmath
from calkowanie import prepareFunction


def assembler(a):
    '''Składa graf do formy ciągu znaków.

    a-równanie w postaci listy zagnieżdżonej'''

    if a[0] == '(':
        return '(' + assembler(a[1]) + ')'
    elif a[0] == '|':
        return '|' + assembler(a[1]) + '|'
    elif a[0] in ["sin","cos","arcsin","arccos"]:
        return a[0] + "(" + assembler(a[1]) + ")"
    elif a[0] not in "+-/*^":
        return a
    else:
        return assembler(a[1]) + a[0] + assembler(a[2])

def preextension(a):
    '''Usuwa z dwumianu Newtona potęgowanie. Jest to pierwszy
    krok do przekształcenia dwumianu na postać we wzorze de Moivre'a.'''

    for item in a:
        if item not in ['^', "n"]:
            return item
    return a

def extension(a):
    '''Zamienia w grafie zmienne a i b w dwumianie (a+(b*j))^n tak aby
     uzyskać ich postać biegunową,a następnie podnosi obie 
     współrzędne biegunowe do odpowiedniej potęgi poprzez zwielokrotnienie
     miary kąta.'''

    if a[0] in "+-/*^":
        a[1] = extension(a[1])
        a[2] = extension(a[2])
    elif a[0] in '(|':
        a[1] = extension(a[1])
    elif a[0] == "a":
        return ["cos", ["*", "n", ["arccos", ["(", ["/", "a", ["^", ["(", ["+", ["^", "a", "2"], ["^", "b", "2"]]], ["(", ["/", "1", "2"]]]]]]]]
    elif a[0] == "b":
        return ["sin", ["*", "n", ["arcsin", ["(", ["/", "b", ["^", ["(", ["+", ["^", "a", "2"], ["^", "b", "2"]]], ["(", ["/", "1", "2"]]]]]]]]

    return a

def postextension(a):
    '''Rozszerza przekształcony w funkcji extension graf o pomnożenie
    przez moduł liczby zespolonej podniesiony do potęgi.'''

    return ["*", ["(", ["^", ["(", ["+", ["^", "a", "2"], ["^", "b", "2"]]], ["(", ["/", "n", "2"]]]], a]

def equation(a):
    '''Przekształca dwumian Newtona liczb zespolonych na postać użytą
    we wzorze de Moivre'a.'''

    extended = preextension(a)
    extended = extension(extended)
    return postextension(extended)
   
def calcBinominal(a, vardict):
    '''Oblicza wartość dwumianu.
    
    a-graf w postaci listy zagnieżdżonej,
    values-słownik zawierający wszystkie zmienne wraz z ich wartościami'''

    if a[0] == "|":
        return abs(calcBinominal(a[1], vardict))
    elif a[0] == "(":
        return complex(calcBinominal(a[1], vardict))
    elif a[0] == "sin":
        return cmath.sin(calcBinominal(a[1], vardict))
    elif a[0] == "cos":
        return cmath.cos(calcBinominal(a[1], vardict))
    elif a[0] == "arcsin":
        return cmath.asin(calcBinominal(a[1], vardict))
    elif a[0] == "arccos":
        return cmath.acos(calcBinominal(a[1], vardict))
    elif a[0] == "+":
        return complex(calcBinominal(a[1], vardict) + calcBinominal(a[2], vardict))
    elif a[0] == "-":
        return complex(calcBinominal(a[1], vardict) - calcBinominal(a[2], vardict))
    elif a[0] == "*":
        return complex(calcBinominal(a[1], vardict) * calcBinominal(a[2], vardict))
    elif a[0] == "/":
        return complex(calcBinominal(a[1], vardict) / calcBinominal(a[2], vardict))
    elif a[0] == "^":
        return complex(calcBinominal(a[1], vardict) ** calcBinominal(a[2], vardict))
    elif a in vardict:
        return complex(vardict[a])
    elif a[0] == "j":
        return complex(0, 1)
    else:
        return complex(a)

def binomial(function, variables):
    '''Zamienia dwumian Newtona na postać używaną we wzorze de Moivre'a.
    Zwraca wynik równania w postaci ciągu znaków.
    
    function-dwumian,
    variables-lista zmiennych'''

    #tworzy graf
    final = prepareFunction(function)
    #zamienia postać na tą u de Moivre'a
    result = equation(final)
    
    vardict = {
        "a" : variables[0],
        "b" : variables[1],
        "n" : variables[2],
    }

    return str(calcBinominal(result, vardict))

def binomialEquation(function, variables):
    '''Zamienia dwumian newtona na postać używaną we wzorze de Moivre'a.
    Zwraca równanie w postaci ciągu znaków.
    
    function-dwumian,
    variables-lista zmiennych'''

    #tworzy graf
    final = prepareFunction(function)
    #zamienia postać na tą u de Moivre'a
    result = equation(final)

    return assembler(result)

def binomialFile(input="input.txt", output="output.txt", r=False):
    '''Odczytuje podane zmienne z równania w postaci dwumianu 
    a następnie przetważa je i zapisuje gotowy wynik działania do pliku wyjściowego.

    input-plik wejściowy(domyślnie input.txt),
    output-plik wyjściowy(domyślnie output.txt),
    r-zmienna informująca czy funkcja ma zwracać graf w postaci ciągu znaków'''
    

    with open(input, "r") as f:
        a = f.read()
        a = a.strip('\n')
    
    #oddziela zmienne od równania
    function, variables = a.split(" ", 1)
    #oddziela zmienne od siebie
    variables = variables.split(" ")

    result = binomial(function, variables)

    with open(output, "a") as f:
        f.write(result)
        f.write('\n')

    if r:
        return result

def binomialEqFile(input="input.txt", output="output.txt", r=False):
    '''Odczytuje podane zmienne z równania w postaci dwumianu 
    a następnie przetważa je i zapisuje gotowy wzór do pliku wyjściowego.

    input-plik wejściowy(domyślnie input.txt),
    output-plik wyjściowy(domyślnie output.txt),
    r-zmienna informująca czy funkcja ma zwracać graf w postaci ciągu znaków'''
    

    with open(input, "r") as f:
        a = f.read()
        a = a.strip('\n')
    
    #oddziela zmienne od równania
    function, variables = a.split(" ", 1)
    #oddziela zmienne od siebie
    variables = variables.split(" ")

    result = binomialEquation(function, variables)

    with open(output, "a") as f:
        f.write(result)
        f.write('\n')

    if r:
        return result
